import { redirect } from "next/navigation";

export default function ClientPortalHomePage() {
  redirect("/portal/ordenes");
}
