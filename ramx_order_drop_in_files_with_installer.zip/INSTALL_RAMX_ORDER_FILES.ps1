# Ejecutar este script desde la carpeta donde se descomprimio este ZIP.
# Copia los archivos modificados hacia la raiz del proyecto RAMX que indiques.

param(
  [string]$ProjectPath = "C:\dev\ramx-app"
)

if (!(Test-Path $ProjectPath)) {
  Write-Error "No existe la ruta del proyecto: $ProjectPath"
  exit 1
}

Write-Host "Copiando archivos modificados a: $ProjectPath"

$folders = @("app", "lib", "public", "supabase")
foreach ($folder in $folders) {
  $source = Join-Path $PSScriptRoot $folder
  $target = Join-Path $ProjectPath $folder

  if (Test-Path $source) {
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    Copy-Item -Path (Join-Path $source "*") -Destination $target -Recurse -Force
    Write-Host "OK: $folder"
  }
}

Write-Host "Listo. Ahora entra al proyecto y corre: npm run build"
